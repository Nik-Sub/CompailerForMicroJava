// generated with ast extension for cup
// version 0.8
// 14/0/2024 20:21:6


package rs.ac.bg.etf.pp1.ast;

public class VarDeclClass extends VarDecl {

    private Type Type;
    private KindOfVar KindOfVar;
    private ListVarDecl ListVarDecl;

    public VarDeclClass (Type Type, KindOfVar KindOfVar, ListVarDecl ListVarDecl) {
        this.Type=Type;
        if(Type!=null) Type.setParent(this);
        this.KindOfVar=KindOfVar;
        if(KindOfVar!=null) KindOfVar.setParent(this);
        this.ListVarDecl=ListVarDecl;
        if(ListVarDecl!=null) ListVarDecl.setParent(this);
    }

    public Type getType() {
        return Type;
    }

    public void setType(Type Type) {
        this.Type=Type;
    }

    public KindOfVar getKindOfVar() {
        return KindOfVar;
    }

    public void setKindOfVar(KindOfVar KindOfVar) {
        this.KindOfVar=KindOfVar;
    }

    public ListVarDecl getListVarDecl() {
        return ListVarDecl;
    }

    public void setListVarDecl(ListVarDecl ListVarDecl) {
        this.ListVarDecl=ListVarDecl;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(Type!=null) Type.accept(visitor);
        if(KindOfVar!=null) KindOfVar.accept(visitor);
        if(ListVarDecl!=null) ListVarDecl.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(Type!=null) Type.traverseTopDown(visitor);
        if(KindOfVar!=null) KindOfVar.traverseTopDown(visitor);
        if(ListVarDecl!=null) ListVarDecl.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(Type!=null) Type.traverseBottomUp(visitor);
        if(KindOfVar!=null) KindOfVar.traverseBottomUp(visitor);
        if(ListVarDecl!=null) ListVarDecl.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarDeclClass(\n");

        if(Type!=null)
            buffer.append(Type.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(KindOfVar!=null)
            buffer.append(KindOfVar.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ListVarDecl!=null)
            buffer.append(ListVarDecl.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarDeclClass]");
        return buffer.toString();
    }
}
