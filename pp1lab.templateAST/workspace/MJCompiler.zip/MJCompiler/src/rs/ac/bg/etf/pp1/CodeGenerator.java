package rs.ac.bg.etf.pp1;

import rs.ac.bg.etf.pp1.ast.VisitorAdaptor;
import rs.etf.pp1.mj.runtime.Code;
import rs.etf.pp1.symboltable.Tab;
import rs.etf.pp1.symboltable.concepts.Obj;
import rs.ac.bg.etf.pp1.CounterVisitor.FormParamCounter;
import rs.ac.bg.etf.pp1.CounterVisitor.VarCounter;
import rs.ac.bg.etf.pp1.ast.*;

public class CodeGenerator extends VisitorAdaptor {

	private int mainPc;
	
	public int getMainPc() {
		return mainPc;
	}
	
	public void visit(PrintClass printStmt) {
		if (printStmt.getExpr().struct == Tab.intType) {
			Code.loadConst(5);
			Code.put(Code.print);
		}
		else {
			Code.loadConst(1);
			Code.put(Code.bprint);
		}
	}
	
	// constants are not in Table of symbols, we are pushing them on the stack directly
	
//	public void visit(BoolConstClass boolConst) {
//		Obj con = Tab.insert(Obj.Con, "$", boolConst.struct);
//		con.setLevel(0);
//		con.setAdr(Integer.parseInt(boolConst.getB1()));
//		
//		Code.load(con);
//	}
	
	
	public void visit(NumberClass number) {
		Obj con = Tab.insert(Obj.Con, "$", number.struct);
		con.setLevel(0);
		con.setAdr(number.getN1());
		
		Code.load(con);
	}
	
	public void visit(LetterClass letter) {
		Obj con = Tab.insert(Obj.Con, "$", letter.struct);
		con.setLevel(0);
		con.setAdr(letter.getL1());
		
		Code.load(con);
	}
	
	public void visit(ReturnTypeClass methWithReturn) {
		
		if ("main".equalsIgnoreCase(methWithReturn.getMethName())) {
			mainPc = Code.pc;
		}
		methWithReturn.obj.setAdr(Code.pc);
		
		//Collect arguments and local variables
		SyntaxNode methodNode = methWithReturn.getParent();
		
		VarCounter varCnt = new VarCounter();
		methodNode.traverseTopDown(varCnt);
		
		FormParamCounter fpCnt = new FormParamCounter();
		methodNode.traverseTopDown(fpCnt);
		
		// Generate the entry
		Code.put(Code.enter);
		Code.put(fpCnt.getCount());
		Code.put(fpCnt.getCount() + varCnt.getCount());
		
	}
	
	public void visit(MethodDeclClass methodDecl) {
		Code.put(Code.exit);
		Code.put(Code.return_);
	}
	
	public void visit(VoidRetTypeClass methWithNoReturn) {
			
		if ("main".equalsIgnoreCase(methWithNoReturn.getMethName())) {
			mainPc = Code.pc;
		}
		methWithNoReturn.obj.setAdr(Code.pc);
		
		//Collect arguments and local variables
		SyntaxNode methodNode = methWithNoReturn.getParent();
		
		VarCounter varCnt = new VarCounter();
		methodNode.traverseTopDown(varCnt);
		
		FormParamCounter fpCnt = new FormParamCounter();
		methodNode.traverseTopDown(fpCnt);
		
		// Generate the entry
		Code.put(Code.enter);
		Code.put(fpCnt.getCount());
		Code.put(fpCnt.getCount() + varCnt.getCount());
	}
	
	
	public void visit(AssignOperatorClass assignment) {
		Code.store(assignment.getDesignator().obj);
	}
	
	public void visit(DesignatorClass designator) {
		SyntaxNode parent = designator.getParent();
		
		// this is the case where we are assigning value to the designator
		if (AssignOperatorClass.class != parent.getClass() && FunCallClass.class != parent.getClass()) {
			Code.load(designator.obj);
		}
		
	}
	
	public void visit(FuncCall funcCall) {
		Code.put(Code.call);
	}
	
}
